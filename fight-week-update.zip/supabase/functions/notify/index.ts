// Fight Week push notifications.
// Called by the database (card changes, Friday reminder schedule) with the shared secret,
// or by a signed-in player to send themselves a test notification.
import webpush from "npm:web-push@3.6.7";
import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
  auth: { persistSession: false },
});

type Prefs = { fight_cancelled: boolean; fight_added: boolean; friday_reminder: boolean };
type Sub = { endpoint: string; user_id: string; p256dh: string; auth: string };
type Payload = { title: string; body: string; tag: string; url?: string };

let configured = false;
async function config() {
  const { data, error } = await admin.rpc("fw_push_config");
  if (error || !data) throw new Error("push config unavailable");
  if (!configured) {
    webpush.setVapidDetails(data.fw_vapid_subject, data.fw_vapid_public, data.fw_vapid_private);
    configured = true;
  }
  return data as Record<string, string>;
}

async function subsFor(userIds?: string[]): Promise<Sub[]> {
  let q = admin.from("push_subscriptions").select("endpoint,user_id,p256dh,auth");
  if (userIds) q = q.in("user_id", userIds);
  const { data } = await q;
  return (data || []) as Sub[];
}
async function prefsMap(): Promise<Record<string, Prefs>> {
  const { data } = await admin.from("notify_prefs").select("user_id,fight_cancelled,fight_added,friday_reminder");
  return Object.fromEntries((data || []).map((p: any) => [p.user_id, p]));
}
const DEFAULT_PREFS: Prefs = { fight_cancelled: true, fight_added: true, friday_reminder: true };

async function send(sub: Sub, payload: Payload) {
  try {
    await webpush.sendNotification(
      { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
      JSON.stringify({ url: "/", ...payload }),
      { TTL: 60 * 60 * 12, urgency: "normal" },
    );
    return true;
  } catch (e: any) {
    // the device unsubscribed or the browser dropped it: forget it
    if (e?.statusCode === 404 || e?.statusCode === 410) {
      await admin.from("push_subscriptions").delete().eq("endpoint", sub.endpoint);
    } else {
      console.error("push failed", e?.statusCode, e?.body || e?.message);
    }
    return false;
  }
}

const bout = (f: any) => `${f?.red ?? "?"} vs ${f?.blue ?? "?"}`;

// cancelled / added bouts, grouped into one notification per card per player
async function runQueue() {
  const { data: rows } = await admin.from("notify_queue").select("id,kind,card_id,fight")
    .is("sent_at", null).in("kind", ["cancelled", "added"]).order("id");
  if (!rows || !rows.length) return { sent: 0 };
  const ids = rows.map((r: any) => r.id);
  // claim the rows first so an overlapping run can't send them twice
  await admin.from("notify_queue").update({ sent_at: new Date().toISOString() }).in("id", ids);

  const cardIds = [...new Set(rows.map((r: any) => r.card_id))];
  const { data: cards } = await admin.from("cards").select("id,name,lock_at,locked").in("id", cardIds);
  const cardById = Object.fromEntries((cards || []).map((c: any) => [c.id, c]));
  const prefs = await prefsMap();
  const subs = await subsFor();
  let sent = 0;

  for (const cid of cardIds) {
    const c = cardById[cid];
    if (!c || c.locked || (c.lock_at && Date.now() >= Date.parse(c.lock_at))) continue;
    const cancelled = rows.filter((r: any) => r.card_id === cid && r.kind === "cancelled").map((r: any) => r.fight);
    const added = rows.filter((r: any) => r.card_id === cid && r.kind === "added").map((r: any) => r.fight);
    for (const s of subs) {
      const p = prefs[s.user_id] || DEFAULT_PREFS;
      const lines: string[] = [];
      if (p.fight_cancelled) cancelled.forEach((f: any) => lines.push(`${bout(f)} is off the card.`));
      if (p.fight_added) added.forEach((f: any) => lines.push(`New bout: ${bout(f)}${f?.weight ? ` (${f.weight})` : ""}.`));
      if (!lines.length) continue;
      const onlyCancel = p.fight_cancelled && cancelled.length && !(p.fight_added && added.length);
      const onlyAdd = p.fight_added && added.length && !(p.fight_cancelled && cancelled.length);
      const title = onlyCancel ? `${c.name}: fight cancelled` : onlyAdd ? `${c.name}: fight added` : `${c.name}: card update`;
      const tail = onlyCancel ? " Your pick on it won't count." : " Make your pick before the card starts.";
      if (await send(s, { title, body: lines.join(" ") + tail, tag: `card-${cid}` })) sent++;
    }
  }
  return { sent };
}

function nyParts(d: Date) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York", weekday: "short", hour: "numeric", hour12: false,
  }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value || "";
  return { weekday: get("weekday"), hour: Number(get("hour")) % 24 };
}
function fmtLock(iso: string) {
  return new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", hour: "numeric", minute: "2-digit" })
    .format(new Date(iso)).replace(":00", "") + " ET";
}

// Friday 5 PM Eastern: picks lock tomorrow when the card starts
async function runFriday(force: boolean) {
  const now = new Date();
  const ny = nyParts(now);
  if (!force && !(ny.weekday === "Fri" && ny.hour === 17)) return { skipped: "not 5 PM Friday in New York" };
  const until = new Date(now.getTime() + 40 * 3600 * 1000).toISOString();
  const { data: cards } = await admin.from("cards").select("id,name,lock_at,locked")
    .eq("locked", false).gt("lock_at", now.toISOString()).lte("lock_at", until);
  if (!cards || !cards.length) return { sent: 0, note: "no card locks in the next day" };
  const prefs = await prefsMap();
  const subs = await subsFor();
  let sent = 0;
  for (const c of cards) {
    if (!force) {
      const { error } = await admin.from("notify_queue").insert({ kind: "friday", card_id: c.id, sent_at: now.toISOString() });
      if (error) continue; // already sent for this card
    }
    for (const s of subs) {
      const p = prefs[s.user_id] || DEFAULT_PREFS;
      if (!p.friday_reminder) continue;
      const ok = await send(s, {
        title: "Picks lock tomorrow",
        body: `${c.name} picks lock at ${fmtLock(c.lock_at)} tomorrow, when the card starts. Get your picks and lock in.`,
        tag: `friday-${c.id}`,
      });
      if (ok) sent++;
    }
  }
  return { sent };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  let body: any = {};
  try { body = await req.json(); } catch { /* empty body */ }

  let cfg: Record<string, string>;
  try { cfg = await config(); } catch { return json({ error: "not configured" }, 500); }

  const secretOk = !!cfg.fw_cron_secret && req.headers.get("x-fw-secret") === cfg.fw_cron_secret;

  if (secretOk && body.job === "queue") return json(await runQueue());
  if (secretOk && body.job === "friday") return json(await runFriday(body.force === true));

  // a signed-in player asking for a test notification on their own devices
  if (body.job === "test") {
    const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
    const { data } = await admin.auth.getUser(token);
    const uid = data?.user?.id;
    if (!uid) return json({ error: "sign in first" }, 401);
    const subs = await subsFor([uid]);
    let sent = 0;
    for (const s of subs) {
      if (await send(s, { title: "Fight Week", body: "Notifications are on. You'll hear from us when the card changes.", tag: "test" })) sent++;
    }
    return json({ sent, devices: subs.length });
  }
  return json({ error: "not allowed" }, 403);
});
